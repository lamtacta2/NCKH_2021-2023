// generated from rosidl_generator_c/resource/idl.h.em
// with input from control_msgs:msg/JointJog.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__JOINT_JOG_H_
#define CONTROL_MSGS__MSG__JOINT_JOG_H_

#include "control_msgs/msg/detail/joint_jog__struct.h"
#include "control_msgs/msg/detail/joint_jog__functions.h"
#include "control_msgs/msg/detail/joint_jog__type_support.h"

#endif  // CONTROL_MSGS__MSG__JOINT_JOG_H_
